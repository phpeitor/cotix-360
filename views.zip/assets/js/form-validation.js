document.addEventListener("DOMContentLoaded", () => {
  const forms = document.querySelectorAll(
    ".form-add-user, .form-upd-user, .form-upd-item, .form-add-item-receta, .form-upd-item-receta"
  );

  const form =
  document.querySelector("form.form-upd-user") ||
  document.querySelector("form.form-upd-item") ||
  document.querySelector("form.form-upd-item-receta");

  const params = new URLSearchParams(window.location.search);
  const hash = params.get("hash");
  const modeloItemRecetaInput = document.querySelector("form.form-add-item-receta #modelo");

  function setModeloDuplicadoState(isDuplicado) {
    if (!modeloItemRecetaInput) {
      return;
    }

    modeloItemRecetaInput.classList.toggle("is-invalid", isDuplicado);
    modeloItemRecetaInput.classList.toggle("border-danger", isDuplicado);
  }

  if (modeloItemRecetaInput) {
    modeloItemRecetaInput.addEventListener("input", () => {
      setModeloDuplicadoState(false);
    });
  }


  /* =====================================================
     AUTOCOMPLETAR NOMBRES/APELLIDOS POR DNI (8 DÍGITOS)
  ===================================================== */
  const documentoInput = document.getElementById("documento");
  const nombresInput   = document.getElementById("nombres");
  const apellidosInput = document.getElementById("apellidos");

  let lastDniConsulted = null;

  if (documentoInput) {
    documentoInput.addEventListener("keyup", async () => {
      const dni = documentoInput.value.trim();

      if (dni.length < 8) {
        lastDniConsulted = null;
        nombresInput.readOnly = false;
        apellidosInput.readOnly = false;
        return;
      }

      if (dni.length !== 8 || dni === lastDniConsulted) return;

      lastDniConsulted = dni;

      try {
        nombresInput.value = '';
        apellidosInput.value = '';

        const res = await fetch(
          `./config/api.php?dni=${dni}`
        );

        if (!res.ok) throw new Error("Error API DNI");

        const data = await res.json();

        if (data.found_patient) {
          nombresInput.value   = data.found_patient.name ?? '';
          apellidosInput.value = data.found_patient.last_name ?? '';
        }

      } catch (err) {
        console.error("❌ Error DNI:", err);
        lastDniConsulted = null;
      }
    });
  }
  /* ================= FIN BLOQUE DNI ================= */

  if (hash && form.classList.contains("form-upd-user")) {
     cargarUsuario(hash);
     prepararFormularioEdicion(form, hash);
  }

  if (hash && form.classList.contains("form-upd-item")) {
    cargarItem(hash);
    prepararFormularioEdicion(form, hash);
  }

  if (hash && form.classList.contains("form-upd-item-receta")) {
    cargarItemReceta(hash);
    prepararFormularioEdicion(form, hash);
  }

  forms.forEach((form) => {
    form.addEventListener("submit", async (e) => {
      e.preventDefault();
      const submitBtn = form.querySelector("[type='submit']");
      const okCustom = typeof validateForm === "function" ? validateForm(form) : true;

      if (!okCustom) {
        form.reportValidity?.();
        return;
      }

      if (!form.checkValidity()) {
        form.classList.add("was-validated");
        form.reportValidity?.();
        return;
      }

      if (submitBtn) {
        if (submitBtn.disabled) return;
        submitBtn.disabled = true;
        submitBtn.classList.add("opacity-50", "cursor-not-allowed");
      }

      let actionUrl = "";
      let redirectUrl = "";

      if (["form-add-user", "form-upd-user"].some(c => form.classList.contains(c))) {
        const isUpdate = form.dataset.mode === "update";
        actionUrl = isUpdate
          ? "controller/upd_usuario.php"
          : "controller/add_usuario.php";
        redirectUrl = "usuarios.php";
      }

      if (form.classList.contains("form-upd-item")) {
        actionUrl = "controller/upd_item.php";
        redirectUrl = "items.php";
      }

      if (["form-add-item-receta", "form-upd-item-receta"].some(c => form.classList.contains(c))) {
        const isUpdate = form.dataset.mode === "update";
        actionUrl = isUpdate
          ? "controller/upd_item_receta.php"
          : "controller/add_item_receta.php";
        redirectUrl = "items_receta.php";
      }

      try {
        const formData = new FormData(form);
        const isAddItemReceta = form.classList.contains("form-add-item-receta") && !form.classList.contains("form-upd-item-receta");

        if (!actionUrl) {
          alertify.error("No se pudo determinar la acción del formulario");
          return;
        }

        const res = await fetch(actionUrl, {
          method: "POST",
          body: formData,
        });

        const ct = res.headers.get("content-type") || "";
        const json = ct.includes("application/json")
          ? await res.json()
          : { ok: false, message: await res.text() };

        if (json.ok) {
          setModeloDuplicadoState(false);
          form.reset();
          window.location.href = redirectUrl;
        } else {
          const mensajeDuplicado = String(json.message || "");
          if ((isAddItemReceta || form.classList.contains("form-upd-item-receta")) && mensajeDuplicado.toLowerCase().includes("codigo ya se encuentra registrado")) {
            setModeloDuplicadoState(true);
          } else {
            setModeloDuplicadoState(false);
          }
          alertify.error("Alerta: " + (json.message || "No se pudo guardar."));
        }

      } catch (err) {
        console.error(err);
        alertify.error("Fallo de red o excepción, revisa consola");

      } finally {
        if (submitBtn) {
          submitBtn.disabled = false;
          submitBtn.classList.remove("opacity-50", "cursor-not-allowed");
        }
      }
    });
  });
  
});

async function cargarUsuario(hash) {
    try {
        const res = await fetch(`controller/get_usuario.php?hash=${hash}`);
        const json = await res.json();

        if (!json.ok) {
            alertify.error(json.message || "Usuario no encontrado");
            return;
        }

        const u = json.data;
        document.querySelector('#nombres').value = u.NOMBRES || '';
        document.querySelector('#apellidos').value = u.APELLIDOS || '';
        document.querySelector('#documento').value = u.DOC || '';
        document.querySelector('#email').value = u.EMAIL || '';
        document.querySelector('#telefono').value = u.TLF || '';
        document.querySelectorAll('input[name="sexo"]').forEach(r => {
            r.checked = parseInt(r.value) === parseInt(u.SEXO);
        });
        document.querySelector('#switch3').checked = parseInt(u.IDESTADO) === 1;
        const cargoSelect = document.querySelector('#cargo');
        if (cargoSelect && u.CARGO) {
            cargoSelect.value = u.CARGO;
        }

    } catch (err) {
        console.error("❌ Error al cargar usuario:", err);
    }
}

async function cargarItem(hash) {
    try {
        const res = await fetch(`controller/get_item.php?hash=${hash}`);
        const json = await res.json();

        if (!json.ok) {
            alertify.error(json.message || "Item no encontrado");
            return;
        }

        const i = json.data;

        document.querySelector('#descripcion').value = i.descripcion ?? '';
        document.querySelector('#modelo').value = i.modelo ?? '';
        document.querySelector('#categoria').value = i.categoria_producto ?? '';
        document.querySelector('#grupo').value = i.grupo_descuento ?? '';
        document.querySelector('#clase').value = i.clase_producto ?? '';
        document.querySelector('#origen').value = i.pais_origen ?? i.origen;
        document.querySelector('#peso').value = i.peso ?? '';
        document.querySelector('#precio').value = i.precio_unitario ?? '';
        document.querySelector('#switch3').checked = parseInt(i.estado) === 1;

    } catch (err) {
        console.error("❌ Error al cargar item:", err);
    }
}

async function cargarItemReceta(hash) {
  try {
    const res = await fetch(`controller/get_item_receta.php?hash=${hash}`);
    const json = await res.json();

    if (!json.ok) {
      alertify.error(json.message || "Item receta no encontrado");
      return;
    }

    const i = json.data;

    const tipoEl = document.querySelector('#filterTipo');
    const categoriaEl = document.querySelector('#filterCategoria');
    const subCat1El = document.querySelector('#filterSubCategoria1');
    const subCat2El = document.querySelector('#filterSubCategoria2');

    if (window.recetaItemSelects?.setSelection) {
      await window.recetaItemSelects.setSelection({
        tipo: i.tipo ?? '',
        categoria: i.categoria ?? '',
        sub_cat_1: i.sub_cat_1 ?? '',
        sub_cat_2: i.sub_cat_2 ?? ''
      });
    } else {
      if (tipoEl) tipoEl.value = i.tipo ?? '';
      if (categoriaEl) categoriaEl.value = i.categoria ?? '';
      if (subCat1El) subCat1El.value = i.sub_cat_1 ?? '';
      if (subCat2El) subCat2El.value = i.sub_cat_2 ?? '';
    }

    document.querySelector('#nombre').value = i.nombre ?? '';
    document.querySelector('#descripcion').value = i.descripcion ?? '';
    document.querySelector('#modelo').value = i.modelo ?? '';
    document.querySelector('#marca').value = i.marca ?? '';
    document.querySelector('#uni_medida').value = i.uni_medida ?? '';
    if (document.querySelector('#stock')) {
      document.querySelector('#stock').value = i.stock ?? 0;
    }
    document.querySelector('#moneda').value = i.moneda ?? '';
    const precioEl = document.querySelector('#precio');
    if (precioEl) {
      precioEl.value = i.precio ?? '';
    }
    document.querySelector('#switch3').checked = parseInt(i.estado) === 1;

  } catch (err) {
    console.error("❌ Error al cargar item receta:", err);
  }
}

function prepararFormularioEdicion(form, hash) {
    if (!hash) return;

    let hidden = form.querySelector("input[name='hash']");
    if (!hidden) {
        hidden = document.createElement("input");
        hidden.type = "hidden";
        hidden.name = "hash";
        hidden.value = hash;
        form.appendChild(hidden);
    }

    form.dataset.mode = "update";
}
