document.addEventListener("DOMContentLoaded", () => {
    const filterTipo = document.getElementById("filterTipo");
    const filterCategoria = document.getElementById("filterCategoria");
    const productoFiltersWrap = document.getElementById("productoFiltersWrap");
    const filterMarca = document.getElementById("filterMarca");
    const filterModelo = document.getElementById("filterModelo");
    const filterSubCategoria1 = document.getElementById("filterSubCategoria1");
    const filterSubCategoria2 = document.getElementById("filterSubCategoria2");
    const btnBuscar = document.getElementById("btn_buscar");
    const btnExportExcel = document.getElementById("btnExportExcel");
    const btnExportExcelSpinner = document.getElementById("btnExportExcelSpinner");
    const btnExportExcelIcon = document.getElementById("btnExportExcelIcon");
    const tableEl = document.getElementById("table-gridjs");
    const alertPrecioCambio = document.getElementById("alertPrecioCambio");
    const userCargo = Number(tableEl?.dataset?.userCargo || 0);
    const ocultaPrecios = [4, 6].includes(userCargo);
    let precioCeroEventSource = null;
    let precioCeroSignature = "";

    function collectOptions(selectEl) {
        return Array.from(selectEl?.options || [])
            .map(opt => opt.value)
            .filter(value => String(value).trim() !== "");
    }

    const initialState = {
        categoria: collectOptions(filterCategoria),
        subCat1: collectOptions(filterSubCategoria1),
        subCat2: collectOptions(filterSubCategoria2)
    };

    function isTipoProducto() {
        return String(filterTipo?.value || "").trim().toUpperCase() === "PRODUCTO";
    }

    function resetNativeSelect(selectEl, placeholder, disabled = true) {
        if (!selectEl) return;

        selectEl.disabled = disabled;

        if (selectEl.choicesInstance) {
            selectEl.choicesInstance.clearChoices();
            selectEl.choicesInstance.setChoices([
                { value: "", label: placeholder, disabled: true, selected: true }
            ], "value", "label", true);
            if (disabled) {
                selectEl.choicesInstance.disable();
            } else {
                selectEl.choicesInstance.enable();
            }
            return;
        }

        selectEl.innerHTML = `<option value="">${placeholder}</option>`;
    }

    function setNativeSelectOptions(selectEl, rows, placeholder, valueKey) {
        if (!selectEl) return;

        const options = rows
            .map(row => row?.[valueKey])
            .filter(value => value !== null && value !== undefined && String(value).trim() !== "")
            .map(value => ({ value, label: value }));

        if (selectEl.choicesInstance) {
            selectEl.disabled = options.length === 0;
            selectEl.choicesInstance.clearChoices();
            selectEl.choicesInstance.setChoices(
                [{ value: "", label: placeholder, disabled: true, selected: true }, ...options],
                "value",
                "label",
                true
            );
            if (options.length === 0) {
                selectEl.choicesInstance.disable();
            } else {
                selectEl.choicesInstance.enable();
            }
            return;
        }

        selectEl.innerHTML = `<option value="">${placeholder}</option>`;

        rows.forEach(row => {
            const value = row?.[valueKey];
            if (value === null || value === undefined || String(value).trim() === "") {
                return;
            }

            const option = document.createElement("option");
            option.value = value;
            option.textContent = value;
            selectEl.appendChild(option);
        });

        selectEl.disabled = rows.length === 0;
    }

    function setOptions(selectEl, values, placeholder = "-- Todas --") {
        if (!selectEl) return;

        const selectedBefore = selectEl.value;
        const uniqueValues = [...new Set(values.map(v => String(v).trim()).filter(Boolean))];

        if (selectEl.choicesInstance) {
            selectEl.disabled = uniqueValues.length === 0;
            selectEl.choicesInstance.clearChoices();
            selectEl.choicesInstance.setChoices(
                [{ value: "", label: placeholder, disabled: true, selected: true }, ...uniqueValues.map(value => ({ value, label: value }))],
                "value",
                "label",
                true
            );
            if (uniqueValues.length === 0) {
                selectEl.choicesInstance.disable();
            } else {
                selectEl.choicesInstance.enable();
            }
            return;
        }

        selectEl.innerHTML = `<option value="">${placeholder}</option>`;

        uniqueValues.forEach(value => {
            const option = document.createElement("option");
            option.value = value;
            option.textContent = value;
            selectEl.appendChild(option);
        });

        if (uniqueValues.includes(selectedBefore)) {
            selectEl.value = selectedBefore;
        } else {
            selectEl.value = "";
        }
    }

    function extractValues(rows, key) {
        return rows
            .map(row => row?.[key])
            .filter(value => value !== null && value !== undefined && String(value).trim() !== "");
    }

    function ocultarAlertaPrecioCero() {
        if (!alertPrecioCambio) return;
        alertPrecioCambio.classList.add("d-none");
        alertPrecioCambio.innerHTML = "";
    }

    function mostrarAlertaPrecioCero(total, items) {
        if (!alertPrecioCambio) return;

        const listado = items.slice(0, 3).map(item => item.nombre || item.modelo || `ID ${item.id}`).join(", ");
        const suffix = listado ? `: ${listado}${items.length > 3 ? "..." : ""}` : "";

        alertPrecioCambio.innerHTML = `<strong>Atención:</strong> Hay ${total} productos con precio en 0${suffix}.`;
        alertPrecioCambio.classList.remove("d-none");
    }

    async function fetchRecetaOpciones(params) {
        const query = new URLSearchParams(params);
        const res = await fetch(`controller/get_receta_item.php?${query.toString()}`);
        const data = await res.json();

        if (!res.ok || !Array.isArray(data)) {
            throw new Error(data?.message || "No se pudieron cargar opciones");
        }

        return data;
    }

        function setExportLoading(loading) {
            if (!btnExportExcel) return;

            btnExportExcel.disabled = loading;
            btnExportExcel.classList.toggle("opacity-75", loading);
            btnExportExcel.classList.toggle("cursor-not-allowed", loading);

            if (btnExportExcelSpinner) {
                btnExportExcelSpinner.classList.toggle("d-none", !loading);
            }

            if (btnExportExcelIcon) {
                btnExportExcelIcon.classList.toggle("d-none", loading);
            }
        }
    async function cargarCategoriasDependientes() {
        const tipo = filterTipo?.value || "";

        if (!tipo) {
            setOptions(filterCategoria, initialState.categoria, "-- Todos --");
            setOptions(filterSubCategoria1, initialState.subCat1, "-- Todas --");
            setOptions(filterSubCategoria2, initialState.subCat2, "-- Todas --");
            resetNativeSelect(filterMarca, "-- Todas --");
            resetNativeSelect(filterModelo, "-- Todas --");
            if (productoFiltersWrap) productoFiltersWrap.classList.add("d-none");
            return;
        }

        const categorias = await fetchRecetaOpciones({ nivel: "categorias", tipo });
        setOptions(filterCategoria, extractValues(categorias, "categoria"), "-- Todos --");

        const subcat1 = await fetchRecetaOpciones({ nivel: "subcat1", tipo });
        setOptions(filterSubCategoria1, extractValues(subcat1, "sub_cat_1"), "-- Todas --");

        const subcat2 = await fetchRecetaOpciones({ nivel: "subcat2", tipo });
        setOptions(filterSubCategoria2, extractValues(subcat2, "sub_cat_2"), "-- Todas --");

        if (!isTipoProducto()) {
            resetNativeSelect(filterMarca, "-- Todas --");
            resetNativeSelect(filterModelo, "-- Todas --");
            if (productoFiltersWrap) productoFiltersWrap.classList.add("d-none");
        }
    }

    async function cargarSubCategorias1Dependientes() {
        const tipo = filterTipo?.value || "";
        const categoria = filterCategoria?.value || "";

        if (!tipo) {
            setOptions(filterSubCategoria1, initialState.subCat1, "-- Todas --");
            setOptions(filterSubCategoria2, initialState.subCat2, "-- Todas --");
            resetNativeSelect(filterMarca, "-- Todas --");
            resetNativeSelect(filterModelo, "-- Todas --");
            return;
        }

        if (isTipoProducto()) {
            if (productoFiltersWrap) productoFiltersWrap.classList.remove("d-none");
            resetNativeSelect(filterMarca, "-- Todas --");
            resetNativeSelect(filterModelo, "-- Todas --");

            if (categoria) {
                const marcas = await fetchRecetaOpciones({ nivel: "marcas", tipo, categoria });
                setNativeSelectOptions(filterMarca, marcas, "-- Todas --", "marca");
            }
        } else if (productoFiltersWrap) {
            productoFiltersWrap.classList.add("d-none");
            resetNativeSelect(filterMarca, "-- Todas --");
            resetNativeSelect(filterModelo, "-- Todas --");
        }

        const subcat1 = await fetchRecetaOpciones({ nivel: "subcat1", tipo, categoria });
        setOptions(filterSubCategoria1, extractValues(subcat1, "sub_cat_1"), "-- Todas --");

        const subcat2 = await fetchRecetaOpciones({ nivel: "subcat2", tipo, categoria });
        setOptions(filterSubCategoria2, extractValues(subcat2, "sub_cat_2"), "-- Todas --");
    }

    async function cargarSubCategorias2Dependientes() {
        const tipo = filterTipo?.value || "";
        const categoria = filterCategoria?.value || "";
        const sub_cat_1 = filterSubCategoria1?.value || "";

        if (!tipo) {
            setOptions(filterSubCategoria2, initialState.subCat2, "-- Todas --");
            resetNativeSelect(filterMarca, "-- Todas --");
            resetNativeSelect(filterModelo, "-- Todas --");
            return;
        }

        const subcat2 = await fetchRecetaOpciones({ nivel: "subcat2", tipo, categoria, sub_cat_1 });
        setOptions(filterSubCategoria2, extractValues(subcat2, "sub_cat_2"), "-- Todas --");
    }

    function getFiltros() {
        const filtros = {
            tipo: filterTipo?.value || "",
            categoria: filterCategoria?.value || "",
            sub_cat_1: filterSubCategoria1?.value || "",
            sub_cat_2: filterSubCategoria2?.value || ""
        };

        if (isTipoProducto()) {
            filtros.marca = filterMarca?.value || "";
            filtros.modelo = filterModelo?.value || "";
        }

        return filtros;
    }

    async function cargarMarcasDependientes() {
        const tipo = filterTipo?.value || "";
        const categoria = filterCategoria?.value || "";

        if (!isTipoProducto()) {
            resetNativeSelect(filterMarca, "-- Todas --");
            resetNativeSelect(filterModelo, "-- Todas --");
            if (productoFiltersWrap) productoFiltersWrap.classList.add("d-none");
            return;
        }

        if (productoFiltersWrap) productoFiltersWrap.classList.toggle("d-none", !categoria);
        resetNativeSelect(filterMarca, "-- Todas --");
        resetNativeSelect(filterModelo, "-- Todas --");

        if (!tipo || !categoria) {
            return;
        }

        const marcas = await fetchRecetaOpciones({ nivel: "marcas", tipo, categoria });
        setNativeSelectOptions(filterMarca, marcas, "-- Todas --", "marca");
    }

    async function cargarModelosDependientes() {
        const tipo = filterTipo?.value || "";
        const categoria = filterCategoria?.value || "";
        const marca = filterMarca?.value || "";

        if (!isTipoProducto()) {
            resetNativeSelect(filterModelo, "-- Todas --");
            return;
        }

        resetNativeSelect(filterModelo, "-- Todas --");

        if (!tipo || !categoria || !marca) {
            return;
        }

        const modelos = await fetchRecetaOpciones({ nivel: "modelos", tipo, categoria, marca });
        setNativeSelectOptions(filterModelo, modelos, "-- Todas --", "modelo");
    }

    async function onMarcaChange() {
        await cargarModelosDependientes();
    }

    async function onModeloChange() {
        await cargarTabla();
    }

    const grid = new gridjs.Grid({
        columns: [
            { id: "id", name: "ID", width: "70px" },
            {
                id: "nombre",
                name: "Nombre Descripción",
                width: "220px",
                formatter: (cell, row) => {
                    const nombre = String(cell || "").trim();
                    const descripcion = String(row?.cells?.[2]?.data || "").trim();

                    if (!descripcion) {
                        return gridjs.html(`<div>${nombre}</div>`);
                    }

                    return gridjs.html(`
                        <div>
                            <div class="fw-semibold">${nombre}</div>
                            <div class="text-muted">${descripcion}</div>
                        </div>
                    `);
                }
            },
            { id: "descripcion", hidden: true },
            {
                id: "categoria",
                name: "Categoría | SubCat1 | SubCat2",
                width: "260px",
                formatter: (cell, row) => {
                    const categoria = String(cell || "").trim();
                    const subCat1 = String(row?.cells?.[4]?.data || "").trim();
                    const subCat2 = String(row?.cells?.[5]?.data || "").trim();
                    const parts = [categoria, subCat1, subCat2].filter(Boolean);

                    return parts.join(" | ") || "-";
                }
            },
            { id: "sub_cat_1", hidden: true },
            { id: "sub_cat_2", hidden: true },
            { id: "marca", name: "Marca", width: "100px" },
            { id: "modelo", name: "Modelo", width: "100px" },
            { id: "uni_medida", name: "Uni. Medida", width: "100px" },
            { id: "tipo", name: "Tipo", width: "110px" },
            {
                id: "precio",
                name: "Precio",
                width: "100px",
                hidden: ocultaPrecios,
                formatter: (cell, row) => {
                    const moneda = row?.cells?.[11]?.data;
                    const simbolo = moneda === "DOLLAR" ? "$" : "S/.";
                    return gridjs.html(`${simbolo} ${Number(cell || 0).toFixed(2)}`);
                }
            },
            { id: "moneda", hidden: true },
            {
                id: "estado",
                name: "Estado",
                width: "80px",
                formatter: (cell) => {
                    const v = String(cell ?? "").trim();
                    if (v === "1") {
                        return gridjs.html(`<span class="badge bg-success">ACTIVE</span>`);
                    }
                    if (v === "0") {
                        return gridjs.html(`<span class="badge bg-danger">SUSPENDED</span>`);
                    }
                    return gridjs.html(`<span class="badge bg-dark text-light">NDF</span>`);
                }
            },
            {
                id: "usuario_cre_nombre",
                name: "Creado por",
                width: "120px",
                sort: false,
                formatter: (cell, row) => {
                    const cells = row.cells;
                    const creador = String(cell ?? "").trim();
                    const editor = String(cells[14]?.data ?? "").trim();
                    const nombre = creador || "—";
                    const tooltip = creador
                        ? (editor && editor !== creador ? `Creado por ${creador} · Editado por ${editor}` : `Creado por ${creador}`)
                        : "Sin registro";
                    return gridjs.html(`<span data-bs-toggle="tooltip" title="${tooltip}">${nombre}</span>`);
                }
            },
            {
                id: "usuario_upd_nombre",
                hidden: true
            },
            {
                id: "acciones",
                name: "Opciones",
                width: "90px",
                sort: false,
                formatter: (_, row) => {
                    const cells = row.cells;

                    const id = cells[0].data;
                    const estado = String(cells[12].data).trim(); 
                    const idHash = md5(String(id));
                    console.log("ID:", id, "Estado:", estado, "Hash:", idHash);

                    const btnDelete = estado === "1"
                    ? `
                        <button class="btn-delete btn btn-soft-danger btn-icon" data-id="${id}">
                            <i class="ti ti-trash-x"></i>
                        </button>
                    `
                    : ``;

                    return gridjs.html(`
                        <div style="gap:.5rem;justify-content:center;">
                            <button class="btn-edit btn btn-outline-primary btn-icon" data-hash="${idHash}">
                                <i class="ti ti-pencil-bolt"></i>
                            </button>
                             ${btnDelete}
                        </div>
                    `);
                }
            }
        ],
        data: [],
        search: true,
        sort: true,
        pagination: {
            enabled: true,
            limit: 10
        }
    }).render(tableEl);

    async function cargarTabla() {
        try {
            const filtros = getFiltros();
            const rows = await fetchRecetaOpciones({ nivel: "items", ...filtros });
            grid.updateConfig({ data: rows }).forceRender();
        } catch (error) {
            console.error(error);
            alertify.error("Error al cargar items receta");
            grid.updateConfig({ data: [] }).forceRender();
        }
    }

    filterTipo?.addEventListener("change", async () => {
        try {
            await cargarCategoriasDependientes();
        } catch (error) {
            console.error(error);
            alertify.error("Error al filtrar categorías");
        }
    });

    filterCategoria?.addEventListener("change", async () => {
        try {
            await cargarSubCategorias1Dependientes();
            if (isTipoProducto()) {
                await cargarMarcasDependientes();
            }
        } catch (error) {
            console.error(error);
            alertify.error("Error al filtrar sub categorías 1");
        }
    });

    filterSubCategoria1?.addEventListener("change", async () => {
        try {
            await cargarSubCategorias2Dependientes();
        } catch (error) {
            console.error(error);
            alertify.error("Error al filtrar sub categorías 2");
        }
    });

    filterMarca?.addEventListener("change", async () => {
        try {
            await onMarcaChange();
        } catch (error) {
            console.error(error);
            alertify.error("Error al filtrar modelos");
        }
    });

    filterModelo?.addEventListener("change", async () => {
        try {
            await onModeloChange();
        } catch (error) {
            console.error(error);
            alertify.error("Error al filtrar items");
        }
    });

    btnBuscar?.addEventListener("click", (event) => {
        event.preventDefault();
        cargarTabla();
    });

        btnExportExcel?.addEventListener("click", async (event) => {
            event.preventDefault();

            if (btnExportExcel.disabled) {
                return;
            }

            setExportLoading(true);

            try {
                const res = await fetch("controller/export_items_receta_excel.php", {
                    method: "GET"
                });

                if (!res.ok) {
                    const text = await res.text();
                    throw new Error(text || "No se pudo generar el Excel");
                }

                const blob = await res.blob();
                const url = window.URL.createObjectURL(blob);
                const a = document.createElement("a");
                a.href = url;
                a.download = `items_receta_${new Date().toISOString().slice(0,19).replace(/[:T]/g, "")}.xlsx`;
                document.body.appendChild(a);
                a.click();
                a.remove();
                window.URL.revokeObjectURL(url);
                alertify.success("Excel generado correctamente");
            } catch (error) {
                console.error(error);
                alertify.error(error.message || "Error al exportar Excel");
            } finally {
                setExportLoading(false);
            }
        });

    function conectarStreamPrecioCero() {
        if (ocultaPrecios || typeof window.EventSource === "undefined") {
            return;
        }

        if (precioCeroEventSource) {
            precioCeroEventSource.close();
            precioCeroEventSource = null;
        }

        precioCeroEventSource = new EventSource("controller/stream_precio_0.php");

        precioCeroEventSource.addEventListener("precio_cero", event => {
            try {
                const payload = JSON.parse(event.data || "{}");
                const total = Number(payload.total || 0);
                const items = Array.isArray(payload.items) ? payload.items : [];
                const nextSignature = `${total}|${items.map(item => item.id).join(",")}`;

                if (precioCeroSignature === nextSignature) {
                    return;
                }

                precioCeroSignature = nextSignature;

                if (total > 0) {
                    mostrarAlertaPrecioCero(total, items);
                    const detalle = items.slice(0, 3).map(item => item.nombre || item.modelo || `ID ${item.id}`).join(", ");
                    const suffix = detalle ? `: ${detalle}${items.length > 3 ? "..." : ""}` : "";
                    alertify.warning(`Hay ${total} productos con precio en 0${suffix}.`);
                } else {
                    ocultarAlertaPrecioCero();
                }
            } catch (error) {
                console.error("Error procesando stream_precio_0:", error);
            }
        });

        precioCeroEventSource.addEventListener("error", () => {
            // EventSource maneja reconexión automática.
        });
    }

    cargarTabla();
    conectarStreamPrecioCero();

    window.addEventListener("beforeunload", () => {
        if (precioCeroEventSource) {
            precioCeroEventSource.close();
            precioCeroEventSource = null;
        }
    });

    document.addEventListener("click", async (e) => {

        // --- BOTÓN EDITAR ---
        const btnEdit = e.target.closest(".btn-edit");
        if (btnEdit) {
            const idHash = btnEdit.getAttribute("data-hash");
            console.log("Editar ID Hash:", idHash);
            if (!idHash) return;
            window.location.href = "upd_item_receta.php?hash=" + idHash;
            return;
        }

        // --- BOTÓN ELIMINAR ---
        const btnDelete = e.target.closest(".btn-delete");
        if (btnDelete) {
            const id = btnDelete.dataset.id;
            if (!id) return;

            const confirmed = await new Promise((resolve) => {
                alertify.confirm(
                    "Confirmar eliminación",
                    "¿Seguro que deseas eliminar el registro " + id + "?",
                    function () { resolve(true); },    // OK
                    function () { resolve(false); }    // Cancelar
                );
            });

            if (!confirmed) return;

            try {
                const res = await fetch("controller/delete_item_receta.php", {
                    method: "POST",
                    headers: { "Content-Type": "application/x-www-form-urlencoded" },
                    body: "id=" + encodeURIComponent(id)
                });

                const json = await res.json();

                if (json.ok) {
                    alertify.success("✅ Registro suspendido correctamente");
                    await cargarTabla();

                } else {
                    alertify.error("❌ Error al suspender: " + json.message);
                }

            } catch (err) {
                console.error(err);
                alertify.error("❌ Error de red al suspender");
            }

            return;
        }

    });

});