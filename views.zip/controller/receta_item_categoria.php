<?php
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../model/item.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

function recetaCategoriaPayload(): array {
    return [
        'tipo' => trim((string)($_POST['tipo'] ?? '')),
        'categoria' => trim((string)($_POST['categoria'] ?? '')),
        'sub_cat_1' => trim((string)($_POST['sub_cat_1'] ?? '')),
        'sub_cat_2' => trim((string)($_POST['sub_cat_2'] ?? '')),
        'estado' => isset($_POST['estado']) ? (int)$_POST['estado'] : 1,
    ];
}

try {
    if (!isset($_SESSION['session_id']) || (int)$_SESSION['session_id'] <= 0) {
        echo json_encode(['ok' => false, 'message' => 'Sesión expirada o usuario no autenticado']);
        exit;
    }

    $item = new Item();
    $action = strtolower(trim((string)($_REQUEST['action'] ?? 'list')));

    if ($_SERVER['REQUEST_METHOD'] === 'GET' && $action === 'list') {
        echo json_encode($item->obtenerRecetaCategoriasGestion(), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        exit;
    }

    if ($_SERVER['REQUEST_METHOD'] === 'GET' && $action === 'order_list') {
        echo json_encode($item->obtenerRecetaSubCat1Orden(), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        exit;
    }

    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        http_response_code(405);
        echo json_encode(['ok' => false, 'message' => 'Método no permitido']);
        exit;
    }

    if ($action === 'delete') {
        $id = (int)($_POST['id'] ?? 0);
        if ($id <= 0) {
            echo json_encode(['ok' => false, 'message' => 'ID no válido']);
            exit;
        }

        echo json_encode([
            'ok' => $item->bajaRecetaCategoria($id),
            'message' => 'Categoría suspendida correctamente'
        ]);
        exit;
    }

    if ($action === 'order_save') {
        $orden = json_decode((string)($_POST['orden'] ?? ''), true);
        if (!is_array($orden) || empty($orden)) {
            echo json_encode(['ok' => false, 'message' => 'No se recibió el orden de sub categorías']);
            exit;
        }

        $item->guardarRecetaSubCat1Orden($orden);
        echo json_encode(['ok' => true, 'message' => 'Orden guardado correctamente']);
        exit;
    }

    $data = recetaCategoriaPayload();
    if ($data['tipo'] === '' || $data['categoria'] === '') {
        echo json_encode(['ok' => false, 'message' => 'Todos los campos son obligatorios']);
        exit;
    }

    if ($data['sub_cat_1'] === '' || $data['sub_cat_2'] === '') {
        echo json_encode(['ok' => false, 'message' => 'Todos los campos son obligatorios']);
        exit;
    }

    if ($action === 'create') {
        $data['estado'] = 1;

        if ($item->existeRecetaCategoria($data)) {
            http_response_code(409);
            echo json_encode(['ok' => false, 'message' => 'Ya existe una categoría con la misma combinación']);
            exit;
        }

        $id = $item->guardarRecetaCategoria($data);
        echo json_encode(['ok' => true, 'id' => $id, 'message' => 'Categoría registrada correctamente']);
        exit;
    }

    if ($action === 'update') {
        $id = (int)($_POST['id'] ?? 0);
        if ($id <= 0) {
            echo json_encode(['ok' => false, 'message' => 'ID no válido']);
            exit;
        }

        if ($item->existeRecetaCategoria($data, $id)) {
            http_response_code(409);
            echo json_encode(['ok' => false, 'message' => 'Ya existe una categoría con la misma combinación']);
            exit;
        }

        $item->actualizarRecetaCategoria($id, $data);
        echo json_encode(['ok' => true, 'message' => 'Categoría actualizada correctamente']);
        exit;
    }

    echo json_encode(['ok' => false, 'message' => 'Acción no válida']);
} catch (PDOException $e) {
    $isDuplicate = $e->getCode() === '23000';
    http_response_code($isDuplicate ? 409 : 500);
    echo json_encode([
        'ok' => false,
        'message' => $isDuplicate ? 'Ya existe una categoría con la misma combinación' : 'Error de base de datos: ' . $e->getMessage()
    ]);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['ok' => false, 'message' => 'Error del servidor: ' . $e->getMessage()]);
}
