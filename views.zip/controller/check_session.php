<?php
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}
require_once __DIR__ . '/../config/permisos.php';

$max_inactive = 90 * 60;

if (!isset($_SESSION['session_usuario'], $_SESSION['session_cargo'])) {
    session_unset();
    session_destroy();
    header('Location: ./index.php');
    exit;
}

if (isset($_SESSION['session_time'])) {
    $inactive = time() - $_SESSION['session_time'];

    if ($inactive > $max_inactive) {
        session_unset();
        session_destroy();
        header('Location: ./index.php');
        exit;
    } else {
        $_SESSION['session_time'] = time();
    }
}

$requestPath = parse_url($_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH) ?: '';
$archivoActual = basename($requestPath ?: ($_SERVER['SCRIPT_NAME'] ?? ''));

if ($archivoActual !== '' && !tieneAcceso($archivoActual)) {
    if ($archivoActual === 'home.php') {
        session_unset();
        session_destroy();
        header('Location: ./index.php');
        exit;
    }

    header('Location: ./home.php');
    exit('Acceso denegado');
}
